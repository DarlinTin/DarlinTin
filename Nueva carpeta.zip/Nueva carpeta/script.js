let scene, camera, renderer, cube;
let products = JSON.parse(localStorage.getItem('products')) || [];
let cart = JSON.parse(localStorage.getItem('cart')) || [];
let total = parseFloat(localStorage.getItem('total')) || 0;
let isAdmin = false;

init3D();
renderProducts();

function init3D() {
    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    renderer = new THREE.WebGLRenderer();
    renderer.setSize(window.innerWidth - 300, window.innerHeight * 0.6);
    document.getElementById('scene').appendChild(renderer.domElement);

    const geometry = new THREE.BoxGeometry();
    const material = new THREE.MeshBasicMaterial({ color: 0x00ff00 });
    cube = new THREE.Mesh(geometry, material);
    scene.add(cube);

    camera.position.z = 5;
    animate();
}

function animate() {
    requestAnimationFrame(animate);
    cube.rotation.x += 0.01;
    cube.rotation.y += 0.01;
    renderer.render(scene, camera);
}

function login() {
    let pass = prompt("Introduce la contraseña:");
    if (pass === "12345") {
        document.getElementById('admin').style.display = 'block';
        isAdmin = true;
        alert('Bienvenido, admin.');
        renderProducts();
    } else {
        alert('Contraseña incorrecta.');
    }
}

function logout() {
    document.getElementById('admin').style.display = 'none';
    isAdmin = false;
    alert('Sesión cerrada.');
    renderProducts();
}

function addProduct() {
    const name = document.getElementById('product-name').value;
    const price = parseFloat(document.getElementById('product-price').value);
    const description = document.getElementById('product-description').value;
    const imageInput = document.getElementById('product-image');
    const file = imageInput.files[0];

    if (name && price && description && file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            products.push({ name, price, description, image: e.target.result });
            saveProducts();
            renderProducts();
            alert('Producto agregado.');
        };
        reader.readAsDataURL(file);
    } else {
        alert('Completa todos los campos.');
    }
}

function renderProducts() {
    const container = document.getElementById('products');
    container.innerHTML = '';
    products.forEach((prod, index) => {
        const card = document.createElement('div');
        card.className = 'product-card';
        card.innerHTML = `
            <img src="${prod.image}" alt="${prod.name}">
            <h3>${prod.name}</h3>
            <p>${prod.description}</p>
            <p>💲${prod.price}</p>
            <button onclick="addToCart(${index})">Agregar al carrito</button>
            <a href="https://wa.me/18296191135?text=Hola%20quiero%20comprar%20${encodeURIComponent(prod.name)}" target="_blank">
                <button>WhatsApp</button>
            </a>
        `;

        if (isAdmin) {
            const deleteBtn = document.createElement('button');
            deleteBtn.textContent = 'Eliminar producto';
            deleteBtn.style.backgroundColor = '#f44336';
            deleteBtn.onclick = () => removeProduct(index);
            card.appendChild(deleteBtn);
        }

        container.appendChild(card);
    });
    renderCart();
}

function addToCart(index) {
    cart.push(products[index]);
    total += products[index].price;
    saveCart();
    renderCart();
}

function renderCart() {
    const cartList = document.getElementById('cart-items');
    cartList.innerHTML = '';
    cart.forEach((prod, index) => {
        const li = document.createElement('li');
        li.textContent = `${prod.name} - $${prod.price}`;
        const btn = document.createElement('button');
        btn.textContent = 'Quitar';
        btn.onclick = () => removeFromCart(index);
        li.appendChild(btn);
        cartList.appendChild(li);
    });
    document.getElementById('cart-total').textContent = total.toFixed(2);
}

function removeFromCart(index) {
    total -= cart[index].price;
    cart.splice(index, 1);
    saveCart();
    renderCart();
}

function removeProduct(index) {
    products.splice(index, 1);
    saveProducts();
    renderProducts();
}

function saveProducts() {
    localStorage.setItem('products', JSON.stringify(products));
}

function saveCart() {
    localStorage.setItem('cart', JSON.stringify(cart));
    localStorage.setItem('total', total.toFixed(2));
}
